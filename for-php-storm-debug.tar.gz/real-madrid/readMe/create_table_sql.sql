CREATE TABLE `alice_survey` (
	`id` INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(50) NOT NULL,
	`gender` VARCHAR(50) NOT NULL,
	`region_province` VARCHAR(50) NOT NULL,
	`region_city` VARCHAR(50) NOT NULL,
	`region_district` VARCHAR(50) NOT NULL,
	`age` INT(5) UNSIGNED NOT NULL,
	`education` VARCHAR(50) NOT NULL,
	`email` VARCHAR(50) NOT NULL,
	`referrer` VARCHAR(100) NULL DEFAULT NULL,
	`mobile` INT(20) NOT NULL,
	`wechat_id` VARCHAR(50) NOT NULL,
	`wechat_num` VARCHAR(50) NOT NULL,
	`weibo_id` VARCHAR(50) NOT NULL,
	`weibo_num` VARCHAR(50) NOT NULL,
	`my_referral_code` VARCHAR(50) NOT NULL,
	`register_time` DATETIME NULL DEFAULT NULL,
	`occupation` VARCHAR(50) NOT NULL,
	PRIMARY KEY (`id`)
)
COLLATE='utf8_general_ci'
ENGINE=InnoDB
;
