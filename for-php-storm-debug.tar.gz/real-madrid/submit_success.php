<!DOCTYPE html>
<html>
<head>
	<title>Success</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>

您已成功登记。1661HK.com感谢您的参与。(Success. Thanks for your participation!)
</body>
</html>