<?php
//please modify line 37 to update the url
// session_destroy();
// exit;
session_start();

include 'config.php';
echo $_SESSION['event'].'<br>';

if ($_SESSION['event']!='real-madrid'){
    $_SESSION['event']='real-madrid';
    echo ' changed to '.$event_name. "unsetting session";
    // exit;
    header('Location: logout.php');//this unset session variables and redirect back to f.php
}

if (isset($_SESSION['id'])){//if exists, then the user is logged in. otherwise redirect to enter mobile page
    header('Location: my_home.php');
}


//var_dump($_SESSION);
$_SESSION['error']='';
//date_default_timezone_set("America/New_York");
//date_default_timezone_set("Asia/Hong_Kong");
//echo "Created date is " . date("Y-m-d h:i:sa");
//echo time();

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (!empty($_POST)) {
    //if user is a robot:
    if (!empty($_POST['login'])){
        $_SESSION['error']='we think you are a robot. this site is only open to human<br>';
    }
    include 'config.php';
    if (!$debug){
        //if user enters the wrong captcha:
        if (strtolower($_SESSION['captcha']['code'])!==strtolower($_POST['captcha'])){
            $_SESSION['error']='图片验证码不正确 (Captcha is incorrect) <br>';
        }
    }

    //if user clicked on 'submit' button:
    if (isset($_POST['saveForm'])) {
        //validate all fields:
        extract($_POST);

        if (empty($promotion_event_id) || !is_numeric($promotion_event_id)){
            $_SESSION['error'].='event name is null or not numeric<br>';
        }

        if (empty($name)){
            $_SESSION['error'].='请填写姓名 （Name cannot be empty)<br>';
        }else if (!isUserNameOK($name)){
            $_SESSION['error'].='姓名只能由汉字、字母、数字、或者下划线组成。 (Name can only contain chinese character， letter, number, or underscore.) <br>';
        }

        if (empty($occupation)){
            $_SESSION['error'].='请填写职业 (Occupation cannot be empty)<br>';
        }else if (!isOccupationOK($occupation)){
            $_SESSION['error'].='职业只能由汉字、字母组成。 (Occupation can only contain Chinese character or letter.) <br>';
        }

        if (empty($age)){
            $_SESSION['error'].='请填写年龄 (Age cannot be empty)<br>';
        } else if (!is_numeric($age)){
            $_SESSION['error'].='年龄只能是数字 (Age must be numeric) <br>';
        }

        if (empty($email)){
            $_SESSION['error'].='请填写电子邮箱 (Email cannot be empty)<br>';
        }else{
            $email_2 = test_input($email);
            if (!filter_var($email_2, FILTER_VALIDATE_EMAIL)) {
                $_SESSION['error'] .= "电子邮箱格式不正确 (Invalid email format). <br>";
            }
        }

        // if (!empty($refer) && !is_numeric($refer)){

        // }
        if (empty($mobile)){
            $_SESSION['error'].='请填写手机号 (Please enter mobile)<br>';
        }else if (!is_numeric($mobile)){
            $_SESSION['error'].='手机号只能是数字 (Mobile must be numeric)<br>';
        }else{
            require("database/dbcontroller.php");
            $db_handle = new DBController();
            $result=$db_handle->runQuery('select * from alice_promotions where mobile="'.$mobile.'"');//returns null if empty resultset
            if (!is_null($result)){
                $_SESSION['error'].='此手机号已经注册过 (This mobile has been registered)<br>';
            }
        }


        if (!$debug){
            if (empty($code)){
                $_SESSION['error'].='请填写短信验证码 (Please enter correct SMS verification code) <br>';
            }else if (!is_numeric($code)){
                $_SESSION['error'].='短信验证码只能是数字 (SMS code must be numeric) <br>';
            }
        }

        //fields except mobile verification code passed validation.
        if (empty($_SESSION['error'])){
            if ($debug) {
                echo 'before saving123';
                saveToDatabase_and_login($db_handle);
                echo 'saved';
                return;
            }

            $url="http://".$base_url."/alice/promotions/SMS/SMS.php?action=verify_SMS_code&code=".$code."&mobile=".$mobile;//must be absolute url?
            //$response = get_web_page($url);//note relative path doesn't work
            //------content of get_web_page($url);
            $useragent = $_SERVER['HTTP_USER_AGENT'];
            $strCookie = 'PHPSESSID=' . $_COOKIE['PHPSESSID'] . '; path=/';

            $session_id = session_id();
            session_write_close();

            $ch = curl_init($url);//go here
            curl_setopt($ch,CURLOPT_USERAGENT, $useragent);
            curl_setopt( $ch, CURLOPT_COOKIE, $strCookie );
            //This will make curl_exec return the data instead of outputting it.
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            $response = curl_exec($ch);
            curl_close($ch);
            //-------------------------------------------
            session_start($session_id); // second session_start
            //echo 'here';
            //echo '---'.$response.'  --- ';

            if (strpos($response, 'Fail(1)')!==false || strpos($response, 'Fail(2)')!==false) {
                //echo '1';
                $_SESSION['error']='短信验证码不存在或已过期 (SMS code doesnt exist or expired)';
            }else if(strpos($response, 'Fail(3)')!==false){
                //echo '1';
                $_SESSION['error']='收到验证码后，请不要更改手机号 (Please do not change mobile after receiving SMS code)';
            }else if (strpos($response,'Fail(4)')!==false){
                //echo '2';
                $_SESSION['error']='短信验证码不正确 (Incorrect SMS code)';
            }else if (strpos($response,'Success')!==false){
                //echo '3';generate
                //user entered correct mobile verification code:
                //if all fields passed validation, insert into alice_promotions table:
                echo 'before saving123';
                saveToDatabase_and_login($db_handle);
                echo 'saved';
            }else{
                //echo 'weird';
                $_SESSION['error']='错误，请刷新页面然后重试 (error, please refresh the page and try again) ';
                if ($debug){
                    $_SESSION['error'].=$response;
                }
            }

        }
    }

}



function isUserNameOK($str){// \s represent whitespace in php
    if(preg_match('/^[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+[0-9a-zA-Z_\x{4e00}-\x{9fa5}\s]*[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+$/u',$str)) //字母数字下划线或汉字  The /u modifier in PHP is for unicode support.
        //if(preg_match('/^[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+$/u',$str)) //字母数字下划线或汉字  The /u modifier in PHP is for unicode support.
    {
        //echo 'ok';
        return true;
    }
    else
    {
        //echo 'error';
        return false;
    }
}

function isOccupationOK($str){// \s represent whitespace in php
    if(preg_match('/^[a-zA-Z\x{4e00}-\x{9fa5}]+[a-zA-Z\x{4e00}-\x{9fa5}\s]*[a-zA-Z\x{4e00}-\x{9fa5}]+$/u',$str)) //字母下划线或汉字(letter,chinese character, or space)    The /u modifier in PHP is for unicode support.
        //if(preg_match('/^[0-9a-zA-Z_\x{4e00}-\x{9fa5}]+$/u',$str)) //字母数字下划线或汉字  The /u modifier in PHP is for unicode support.
    {
        //echo 'ok';
        return true;
    }
    else
    {
        //echo 'error';
        return false;
    }
}

//var_dump($db_handle->runQuery('select * from alice_promotions'));

function saveToDatabase_and_login($db_handle){
    ///echo 'here';
    //require('database/dbcontroller.php');
    //echo '....';
    //$db_handle = new DBController();//must add the above 2 lines for mysqli_query to work:to do: use prepare query to avoid sql injection:
    //echo 'ya';
    //----------------generate unique my_referral_code:------------
    $my_referral_code='';

    do {
        $my_referral_code = rand(10000, 99999);
        //$my_referral_code=51057;
        $select_result = $db_handle->runQuery("select * from alice_promotions where my_referral_code='" . $my_referral_code . "'");
        //if ($select_result) echo 'exist';
        //exit;
    }while ($select_result);
    //----------------prize related variables---------------
    require 'config.php';
    //-------------insert user into database-----------------------------------------
    //echo 'province: '.$_POST["provinces"].", city: ".$_POST["citys"].", county:".$_POST["countys"];
   
    $result = $db_handle->runQuery("INSERT INTO alice_promotions(promotion_event_id,name, email, mobile, occupation, my_referral_code, referrer, register_time, gender,age) VALUES(".$_POST['promotion_event_id'].",'".$db_handle->conn->real_escape_string($_POST["name"])."','".$_POST["email"]."','".$_POST["mobile"]."','".$_POST["occupation"]."','".$my_referral_code."','".$db_handle->conn->real_escape_string($_POST["refer"])."', NOW(),'".$db_handle->conn->real_escape_string($_POST["gender"])."','".$_POST["age"]."')");
    //-------------log the user in and redirect if successfully saved. --------------
    if(empty($result)) {
        $_SESSION['error'] = "暂时不能提交信息,请联系工作人员.Problem in submitting information to database. Please Contact our staff.";
        echo 'error:'.$db_handle->getError();
    }else{
        //-------------------rediret to 'submit successfully page' submit_success.php--------------
	    $result = $db_handle->runQuery("select * from alice_promotions where mobile='".$_POST['mobile']."'");
        $_SESSION['id']=$result[0]['id'];
        $_SESSION['name'] = $result[0]['name'];    
        $_SESSION['my_referral_code'] = $result[0]['my_referral_code'];    
        // exit;
        header("Location: my_home.php");
    }
}


// returns true if $needle is a substring of $haystack
function contains($haystack, $needle)
{
    return strpos($haystack, $needle) !== false;
}

/**
 * this curl is aware of the $_SESSION variable my browser sees. if we don't use that, we use get_web_page_no_session(), then SMS.php doesn't have anything in $_SESSION variable.
 * @param $url
 * @return mixed
 */
function get_web_page($url) {
    $useragent = $_SERVER['HTTP_USER_AGENT'];
    $strCookie = 'PHPSESSID=' . $_COOKIE['PHPSESSID'] . '; path=/';

    session_write_close();

    $ch = curl_init($url);//go here
    //curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_USERAGENT, $useragent);
    curl_setopt( $ch, CURLOPT_COOKIE, $strCookie );

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

?>


<?php

include("simple-php-captcha-master/simple-php-captcha.php");
$_SESSION['captcha'] = simple_php_captcha(array(
        'min_length' => 4,
        'max_length' => 4,
        'min_font_size' => 18,
        'max_font_size' => 18,
        'characters' => '0123456789',
    )
);

?>
<html>
<head>
    <!--    <meta charset="UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>1661HK.com客户登记表</title>
    <link href="css/form5.css" type="text/css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="js/jquery.min.js"></script>
    <style type="text/css">
        img#captcha {
            border: solid 1px #ccc;
            margin: 0 1em;
        }
    </style>

</head>

<!-- <body background="scratcher_images/black1.jpg"> -->
<!-- <body background="scratcher_images/blue.jpg"> -->
<body>
<form action="f.php" method="post" autocomplete="on">
    <header>
        <!-- <div class="logo">
            <h1>1661HK.com</h1>
            <hr noshade size=2 width="80%">
            <h3>Sports Fitness Lifestyle</h3>
         </div>-->
        <image style='display: block;margin: 0 auto;float: left;
    width: 100px;' src='scratcher_images/1661HK_Logo_05152015__1.png'>
        </image>
        <br>
        <h2>客户登记表</h2>
        <div>(1) 每个手机号只能登记一次哦</div>
        <div>(2) 如果您已经登记过，请点击 <button class='btn' type='button' onClick="location.href='login.php'" tabindex="1" >查询</button></div>
    </header>

    <?php
    //if there is error in $_SESSION, then show it:
    echo '<div class="error_msg">';
    if (isset($_SESSION['error'])) {
        echo $_SESSION['error'];
    }
    echo '</div>';
    ?>


    <input type="hidden" name="promotion_event_id" value="1">

    <div class="username">
        <div>
            <!--姓名（汉字、字母、数字、或下划线）-->
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="Field1" name="name" type="text" placeholder="姓名" class="field text fn" value="<?php if (isset($_POST['name'])) echo $_POST['name'];?>" size="8" maxlength="255" tabindex="1">
        </div>

        <input type="hidden" name="login" value="">
    </div>

    <div class="gender">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span><span>性别 ：</span>
            <select style="border:2px solid #6096b2;height:32px;" name="gender" id="gender" tabindex="2">
                <?php if ($_POST['gender']=='female'){ ?>
                    <option value="male">男</option>
                    <option value="female" selected>女</option>
                <?php }else{  ?>
                    <option value="male" selected>男</option>
                    <option value="female" >女</option>
                <?php }?>
            </select>
            <!-- <input type="radio" name="gender" id='male' value="male"><label for='male'>男</label>
            <input type="radio" name="gender" id='female' value="female"><label for='female'>女</label> -->
        </div>
    </div>

   
  

    <div class="age">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="age" name="age" type="number" placeholder="年龄" spellcheck="false" value="<?php if (isset($_POST['age'])) echo $_POST['age'];?>" maxlength="255" tabindex="6" required>
        </div>
    </div>

    <div class="occupation">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="occupation" name="occupation" type="text" placeholder="职业(至少两个字)" spellcheck="false" value="<?php if (isset($_POST['occupation'])) echo $_POST['occupation'];?>" maxlength="255" tabindex="7" required>
        </div>
    </div>


    <div class="email-address">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="email" name="email" type="email" placeholder="电子邮箱" spellcheck="false" value="<?php if (isset($_POST['email'])) echo $_POST['email'];?>" maxlength="255" tabindex="9" required>
        </div>
    </div>

    <div class="refer">
        <div>
            <span class='star'>&nbsp;&nbsp;</span>
            <input id="refer" name="refer" type="number" placeholder="介绍人代码" spellcheck="false" value="<?php if (isset($_POST['refer'])) echo $_POST['refer'];?>" maxlength="255" tabindex="10">
        </div>
    </div>

    <div class="cell-number">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="mobile" name="mobile" type="number" placeholder="手机号" value="<?php if (isset($_POST['mobile'])) echo $_POST['mobile'];?>" maxlength="15" tabindex="11">
        </div>
    </div>

    <div class="pic-verification-code">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="captcha" name="captcha" type="number" placeholder="图片验证码" style="width:45%; float:left;" maxlength="15" tabindex="12">
            <!-- <input id="captcha" name="captcha" type="text" placeholder="图片验证码" style="width:45%; float:left;" value="<?php //if (isset($_POST['captcha'])) echo $_POST['captcha'];?>" maxlength="15" tabindex="3"> -->
            <input type="hidden" id="isCaptchaMatch" name="isCaptchaMatch" value="false">
            <?php echo '<img id="captcha" src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';?>
        </div>
    </div>

    <div class="sms-verification-code">
        <div>
            <span class='star'>*&nbsp;&nbsp;</span>
            <input id="code" name="code" type="number" placeholder="短信验证码" style="width:45%; margin-right: 20px;  float:left;" value="<?php if (isset($_POST['code'])) echo $_POST['code'];?>" maxlength="10" tabindex="13">
            <button type="button" id="button1" value="set_SMS_in_session" style="margin-top:3px;  font-size: 14px" class="btn" tabindex="13">免费获取</button>
        </div>
    </div>


<!--     <div>
        <div>
            <input style='width: 10%;float: left;' type="checkbox" name="opt_in" value="opt_in">获得推荐人代码
        </div>
    </div> -->
    <!--finished optional fields-->
    <div >
        <input id="saveForm" name="saveForm" type="submit" value="提交" class="submit" tabindex="17">
    </div>

</form>



<!--获取手机短信之后调用get_code_time函数代码-->
<script>
    //重新获取验证码
    // Variable to hold request
    var request_0;
    var request;

    // Bind to the click event of button1
    $(document).ready(function() {
        $('#captcha').blur(function (){
            /*-----check if the captcha is correct. if not then display the error message-----*/
            /*
             var user_input=$('#captcha').val();
             if (user_input===''){
             //the user enterred nothing in captcha:
             $('.error_msg').html('请先输入图片验证码 (please enter correct captha first)');
             return;
             }
             //there is something, check if it is integer:
             if(!user_input.match(/^\d+$/)){
             //not valid integer
             $('.error_msg').html('验证码只能是数字 (captha must be numeric)');
             return;
             }
             //it is integer, check if it is correct:
             console.log(user_input);
             if (request_0){
             request_0.abort();
             }
             request_0= $.ajax({
             url:"verify_captcha.php",
             type: "get",
             data: {'user_input': user_input}
             });
             // Callback handler that will be called on success
             request_0.done(function (response, textStatus, jqXHR) {
             // Log a message to the console
             //console.log("Hooray, it worked, got response!");
             //console.log(response);
             if (response==='pass'){
             console.log('captcha passed validation.');
             $('#isCaptchaMatch').val('true');
             //console.log($('#isCaptchaMatch').val());
             $('.error_msg').html('');
             }else{
             $('#isCaptchaMatch').val('false');
             $('.error_msg').html('图片验证码不正确 (wrong captcha)');
             }
             });
             // Callback handler that will be called on failure
             request_0.fail(function (jqXHR, textStatus, errorThrown) {
             // Log the error to the console
             console.error(
             "The following error occurred: " +
             textStatus, errorThrown
             );
             $('#isCaptchaMatch').val('false');
             $('.error_msg').html('请输入正确的图片验证码');
             });
             */
        });


        /*user clicked on 'send sms verification code' button*/
        $('#button1').click(function () {
            var button1=this;
            /*---------------check if the mobile field pass validation-------------*/
            var mobile=document.getElementById('mobile').value;
            if (!isCellphone_CN(mobile) && !isCellphone_US(mobile) && !isCellphone_HK(mobile)){
                //alert(isCellphone_CN(mobile));
                //alert(isCellphone_US(mobile));
                //alert(isCellphone_HK(mobile));
                $('.error_msg').html('手机号格式不正确 (mobile is not a valid mobile)');
                return;
            }
            //手机号要么是valid中国的，要么是11位的数字。

            //alert('clicked');
            /*-----check if the captcha is correct. if not then display the error message-----*/

            var user_input=$('#captcha').val();
            if (user_input===''){
                //the user enterred nothing in captcha:
                $('.error_msg').html('请先输入图片验证码 (please enter correct captha first)');
                return;
            }
            //there is something, check if it is integer:
            if(!user_input.match(/^\d+$/)){
                //not valid integer
                $('.error_msg').html('验证码只能是数字 (captha must be numeric)');
                return;
            }
            //it is integer, check if it is correct:
            console.log(user_input);
            if (request_0){
                request_0.abort();
            }
            request_0= $.ajax({
                url:"verify_captcha.php",
                type: "get",
                data: {'user_input': user_input}
            });
            // Callback handler that will be called on success
            request_0.done(function (response, textStatus, jqXHR) {
                // Log a message to the console
                //console.log("Hooray, it worked, got response!");
                console.log(response);
                if (response==='pass'){
                    //console.log('captcha passed validation.');
                    $('#isCaptchaMatch').val('true');
                    //console.log($('#isCaptchaMatch').val());
                    //$('.error_msg').html('');
                    /*----------send to SMS.php to send the text to the mobile number------*/
                    var button_action = button1.value;
                    //alert('here');
                    // Abort any pending request
                    if (request) {
                        request.abort();
                    }
                    //alert('there');
                    button1.innerHTML='请稍后';//change button text to 请稍后,innerHTML not working
                    button1.disabled=true;

                    if (isCellphone_HK(mobile)){
                        //alert('hk'); //is hk number start with 850 (hk country code.). and all are digits.
                        request = $.ajax({
                            url: "SMS/SMS_HK.php", /*please change this accordingly*/
                            type: "get",
                            cache: false,
                            data: {'action': 'set_SMS_in_session', 'mobile': '+'+document.getElementById('mobile').value}
                        });
                    }else if (isCellphone_CN(mobile)) {//is Chinese mobile number:
                        // Fire off the request to php file
                        //alert('CN');
                        request = $.ajax({
                            url: "SMS/SMS.php", /*please change this accordingly*/
                            type: "get",
                            cache: false,
                            data: {'action': 'set_SMS_in_session', 'mobile': document.getElementById('mobile').value}
                        });
                    }else{//is U.S. mobile number.
                        //alert('us');
                        request = $.ajax({
                            url: "SMS/SMS_US.php", /*please change this accordingly*/
                            type: "get",
                            cache: false,
                            data: {'action': 'set_SMS_in_session', 'mobile': document.getElementById('mobile').value}
                        });
                    }
                    // Callback handler that will be called on success
                    request.done(function (response, textStatus, jqXHR) {
                        // Log a message to the console
                        console.log("Hooray, it worked, got response!");
                        console.log(response);
                        if (response.indexOf('Successfully sent out')>-1){
                            //success:
                            get_code_time(button1);
                            $('.error_msg').html('');
                        }else if (response.indexOf('Error: Texting quota expired in this session.')>-1) {
                            button1.disabled=false;
                            button1.innerHTML="免费获取验证码";
                            $('.error_msg').html('失败： 此会话已经超出了发送验证码条数的限制。 Texting quota expired. contact staff.');
                        }else{
                            $('.error_msg').html('发送验证码失败,请过会再试');//error sending out SMS via luosimao.com. please check output from the SMS.php file.
                            button1.innerHTML="免费获取";//reset button text from 'please wait' to 'send SMS verification code'
                        }
                    });

                    // Callback handler that will be called on failure
                    request.fail(function (jqXHR, textStatus, errorThrown) {
                        // Log the error to the console
                        console.error(
                            "The following error occurred: " +
                            textStatus, errorThrown
                        );
                        button1.innerHTML="免费获取验证码";//reset button text from 'please wait' to 'send SMS verification code'
                    });

                    // Callback handler that will be called regardless
                    // if the request failed or succeeded
                    request.always(function () {
                        //                // Reenable the inputs
                        //                button1.prop("disabled", false);
                    });
                }else{
                    $('#isCaptchaMatch').val('false');
                    $('.error_msg').html('请先输入正确的图片验证码 (please enter correct captha first)');
                    return;
                }
            });
            // Callback handler that will be called on failure
            request_0.fail(function (jqXHR, textStatus, errorThrown) {
                // Log the error to the console
                console.error(
                    "The following error occurred: " +
                    textStatus, errorThrown
                );
                $('#isCaptchaMatch').val('false');
                $('.error_msg').html('请先输入正确的图片验证码 (please enter correct captha first)');
                return;
            });
        });
    });

</script>

<!--按钮倒计时代码-->
<script>
    var wait = <?php include_once 'config.php'; echo $texting_interval;?>;
    get_code_time = function (o) {
        if (wait == 0) {
            o.disabled=false;
            o.innerHTML="免费获取验证码";
            wait = <?php echo $texting_interval;?>;
        } else {
            //o.attr("disabled", true);
            o.innerHTML=wait+"秒后重新获取";
            wait--;
            setTimeout(function() {
                get_code_time(o)
            }, 1000)
        }
    }



    /**
     *
     * @descrition:判断输入的参数是否是个合格的手机号码，不能判断号码的有效性，有效性可以通过运营商确定。
     * @param:str ->待判断的手机号码
     * @return: true表示合格输入参数
     *
     */
    var isCellphone_CN = function(str) {
        /**
         *@descrition:手机号码段规则
         * 13段：130、131、132、133、134、135、136、137、138、139
         * 14段：145、147
         * 15段：150、151、152、153、155、156、157、158、159
         * 17段：170、176、177、178
         * 18段：180、181、182、183、184、185、186、187、188、189
         *
         */
        var pattern =  /^(13[0-9]|14[57]|15[012356789]|17[0678]|18[0-9])\d{8}$/;
        return pattern.test(str);
        //return true;
    }

    var isCellphone_US=function(str){
        <?php
            include_once 'config.php';
            if ($allow_us_mobile){
        ?>
        return (str.match(/^\d+$/) && str.length==10 );
        <?php
            }else{
        ?>
        return false;
        <?php
            }
        ?>
        //can change to return false, if you don't allow US mobile number in registration.
    }

    var isCellphone_HK=function(str){
        return str.match(/^852\d{8}$/);// && str.match(/^852/));
    }
</script>
<script type="text/javascript">
    // $("select").change(function() {
    //     var id = $(this).attr('id');
    //     var value = $(this).attr('value');   
    //     //find the select with an id that matched the input name attr and the option within it with the same value.
    //     $("select[id=" + id + "] option[value=" + value + "]").attr('selected', 'selected');
    // });
</script>
<!-- R.1.1 -->
</body>
</html>
