<?php
	$servername = "localhost";
	$username = "root";
	$password = "wireless";
	$db = "magento_1661";
?>