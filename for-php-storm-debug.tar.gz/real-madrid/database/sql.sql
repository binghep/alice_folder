CREATE TABLE IF NOT EXISTS `alice_promotion_real_madrid` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `age` int(5) unsigned NOT NULL,
  `email` varchar(50) NOT NULL,
  `referrer` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) NOT NULL,
  `my_referral_code` varchar(50) NOT NULL,
  `register_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;