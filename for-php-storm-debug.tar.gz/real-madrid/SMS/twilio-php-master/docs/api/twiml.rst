###########################################
API for TwiML Generation
###########################################

.. phpautoclass:: Services_Twilio_Twiml
    :filename: ../Services/Twilio/Twiml.php
    :members:
