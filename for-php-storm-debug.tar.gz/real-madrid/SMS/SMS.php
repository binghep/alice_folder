<?php
session_start();

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'set_SMS_in_session':
            set_SMS_in_session($_GET['mobile']);
            break;
        case 'verify_SMS_code':
            verify_SMS_code($_GET['code'],$_GET['mobile']);
            break;
    }
}

//set_SMS_in_session();
function set_SMS_in_session($mobile){
    //php generate random six-digit code and saves it in Session.
    $num = rand(1000,9999);
    /*----------------prevent spammer--------------*/
    require '../config.php';
    if (!isset($_SESSION['texting_quota'])){
        $_SESSION['texting_quota']=$texting_quota;
    }

    if ($_SESSION['texting_quota']<1) {
        echo 'Error: Texting quota expired in this session.';
        exit;
    }
    /*----------------prevent spammer--------------*/

    $result=sendText($mobile,"您的验证码是：".$num."。【一六六一】");
    //$result=sendText($mobile, $num."（漯河网验证码），请尽快完成验证。【漯河网】");
    /*----------------prevent spammer--------------*/    
    $_SESSION['texting_quota']-=1;
    /*----------------prevent spammer--------------*/



    //if ($result=='{"error":0,"msg":"ok"}'){ //this also works
    if (strpos($result, '"error":0')){
        echo 'Successfully sent out text to mobile';
        //save in session. so later on, we have something to compare with user input (in text boxes)
        $_SESSION['sms_code']=$num;
        $_SESSION['mobile']=$mobile;
    }else{/*参考 https://luosimao.com/docs/api/    */
        //if ($result=='{"error":-50,"msg":"Ip denied:222.72.169.63"}'){
        if (strpos($result,'{"error":-50,"msg":')!==false){
            echo "Error sending out text: IP denied.请查看白名单";
        }else if (strpos($result,'{"error":-40,"msg":')!==false) {
            echo "Error sending out text: invalid mobile number. 错误的手机号.解决方案：检查手机号是否正确";
        }else if (strpos($result,'{"error":-41,"msg":')!==false){
            echo "Error sending out text:  号码因频繁发送或其他原因暂停发送，请联系客服确认";
        }else {
            echo 'Error sending out text.';
            echo $result . ' doesnt equal to ' . '{"error":0,"msg":"ok"}';
        }
    }
}


/**
 * luosimao.com API
 * @param $mobile
 * @param $text_content
 */
function sendText($mobile, $text_content){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://sms-api.luosimao.com/v1/send.json");

    curl_setopt($ch, CURLOPT_HTTP_VERSION  , CURL_HTTP_VERSION_1_0 );
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);

    curl_setopt($ch, CURLOPT_HTTPAUTH , CURLAUTH_BASIC);
    curl_setopt($ch, CURLOPT_USERPWD  , 'api:key-b69f54c9fbc61ad4cfb1ec2ee3a7b3d6');

    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, array('mobile' => $mobile,'message' => $text_content));

    $res = curl_exec( $ch );
    curl_close( $ch );
    //$res  = curl_error( $ch );
    //var_dump($res);
    return $res;
}

function verify_SMS_code($code, $mobile){
    //isset() determine if a variable is set and is not null
    if (!isset($_SESSION['mobile'])){
        echo 'Fail(1). 验证码不存在或已过期';
    }

    if ($_SESSION['mobile']!==$mobile){
        echo 'Fail(3). Mobile was modified after SMS verification.';
        exit;
    }

    if ($_SESSION['sms_code']==$code){
        echo "Success. user entered $code";
    }else{
        echo "Fail(4). user entered $code. expected ". $_SESSION['sms_code'];
    }
}




/*
debug url: http://localhost/f/SMS/SMS_US.php?action=set_SMS_in_session&mobile=4156348157
*/
?>







