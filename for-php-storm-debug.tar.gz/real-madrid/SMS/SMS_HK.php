<?php
session_start();

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'set_SMS_in_session':
            set_SMS_in_session($_GET['mobile']);
            break;
        case 'verify_SMS_code':
            verify_SMS_code($_GET['code'],$_GET['mobile']);
            break;
    }
}

//set_SMS_in_session();
function set_SMS_in_session($mobile){
    //php generate random six-digit code and saves it in Session.
    $num = rand(1000,9999);
    /*----------------prevent spammer--------------*/
    require '../config.php';
    if (!isset($_SESSION['texting_quota'])){
        $_SESSION['texting_quota']=$texting_quota;
    }

    if ($_SESSION['texting_quota']<1) {
        echo 'Error: Texting quota expired in this session.';
        exit;
    }
    /*----------------prevent spammer--------------*/

    //'_get' SMS code to Mobile SMS API. The user recieves it, input the code in input box, click on 'verify' button, triggers the below function.
    //------------------Twilio API----------------------------
    // this line loads the library
    require('twilio-php-master/Services/Twilio.php');

    $account_sid = 'AC83d35f5f371c77a6ac64d00d43c09cf4';
    $auth_token = '8f224085b7a49f7cd93b721f0340bd1f';
    $client = new Services_Twilio($account_sid, $auth_token);

    $client->account->messages->create(array(
        'To'   => $mobile,
        'From' => "+19093036286",
        //'Body' => "尊敬的用户，您的验证码是：".$num."，请在5分钟内输入",
        'Body' => "You verification code is ".$num." [1661HK]",
    ));
    /*----------------prevent spammer--------------*/    
    $_SESSION['texting_quota']-=1;
    /*----------------prevent spammer--------------*/


    //save in session. so later on, we have something to compare with user input (in text boxes)
    $_SESSION['sms_code']=$num;
    $_SESSION['mobile']=substr($mobile,1);//remove the + in front of hk mobile number. 

    echo 'Successfully sent out text to mobile';

}



function verify_SMS_code($code, $mobile){
    //isset() determine if a variable is set and is not null
    if (!isset($_SESSION['mobile'])){
        echo 'Fail. No mobile generated yet.';
    }
    if (!isset($_SESSION['sms_code'])) {
        echo 'Fail. No verification code generated yet.';
        exit;
    }

    if ($_SESSION['mobile']!==$mobile){
        echo 'Fail. Mobile was modified after SMS verification.';
        exit;
    }

    if ($_SESSION['sms_code']==$code){
        echo "Success. user entered $code";
    }else{
        echo "Fail. user entered $code. expected ". $_SESSION['sms_code'];
    }
}


?>




