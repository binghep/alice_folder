<?php
session_start();
if (!isset($_SESSION['id'])){//if exists, then the user is logged in. otherwise redirect to enter mobile page
    header('Location: login.php');
}
// echo '<pre>';
// var_dump($_SESSION);
// echo '</pre>';
require "config.php";
?>
<html>
<head>
<!--    <meta charset="UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>您的刮刮乐和抽奖号码</title>
    <link href="css/form____.css" type="text/css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jquery, CSS, and scripts for scratcher -->
<!--    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>-->
    <script src="js/jquery.min.js"></script>
    <link href="css/scratcher.css" rel="stylesheet" type="text/css"/>
<!--    <script src="js/scratcher.js" type="text/javascript"></script>-->
    <script>
        // depends on jQuery

        (function() {

            var image = { // front images
                //'back': {'url':'http://192.168.0.169/f/QRcode/qr.php/?web=http%3A%2F%2F192.168.0.169%2Fredeem_souvenir.php&id=9&prize=1&raffle=789244', 'img':null },
                'back': {'url':'http://<?php echo $base_url;?>/f/QRcode/qr.php?web=http%3A%2F%2F<?php echo $base_url;?>%2Ff%2Fredeem_souvenir.php&id=<?php echo $_SESSION['id'];?>&raffle_code=<?php echo $_SESSION['raffle_code'];?>&prize=<?php echo $_SESSION['prize'];?>&cell=<?php echo $_SESSION['cell'];?>&register_time=<?php echo urlencode($_SESSION['register_time']);?>', 'img':null },
                'front': { 'url':'scratcher_images/刮刮卡.jpg', 'img':null }
            };

            var canvas = {'temp':null, 'draw':null}; // temp and draw canvases

            var mouseDown = false;


            /**
             * Returns true if this browser supports canvas
             *
             * From http://diveintohtml5.info/
             */
            function supportsCanvas() {
                return !!document.createElement('canvas').getContext;
            }

            /**
             * Helper function to extract the coordinates from an event, whether the
             * event is a mouse or touch.
             */
            function getEventCoords(ev) {
                var first, coords = {};
                var origEv = ev.originalEvent; // get from jQuery

                if (origEv.changedTouches != undefined) {
                    first = origEv.changedTouches[0];
                    coords.pageX = first.pageX;
                    coords.pageY = first.pageY;
                } else {
                    coords.pageX = ev.pageX;
                    coords.pageY = ev.pageY;
                }

                return coords;
            }

            /**
             * Helper function to get the local coords of an event in an element,
             * since offsetX/offsetY are apparently not entirely supported, but
             * offsetLeft/offsetTop/pageX/pageY are!
             *
             * @param elem element in question
             * @param ev the event
             */
            function getLocalCoords(elem, coords) {
                var ox = 0, oy = 0;

                // Walk back up the tree to calculate the total page offset of the
                // currentTarget element.  I can't tell you how happy this makes me.
                // Really.
                while (elem != null) {
                    ox += elem.offsetLeft;
                    oy += elem.offsetTop;
                    elem = elem.offsetParent;
                }

                return { 'x': coords.pageX - ox, 'y': coords.pageY - oy };
            }

            /**
             * Recomposites the canvases onto the screen
             *
             * Note that my preferred method (putting the background down, then the
             * masked foreground) doesn't seem to work in FF with "source-out"
             * compositing mode (it just leaves the destination canvas blank.)  I
             * like this method because mentally it makes sense to have the
             * foreground drawn on top of the background.
             *
             * Instead, to get the same effect, we draw the whole foreground image,
             * and then mask the background (with "source-atop", which FF seems
             * happy with) and stamp that on top.  The final result is the same, but
             * it's a little bit weird since we're stamping the background on the
             * foreground.
             *
             * OPTIMIZATION: This naively redraws the entire canvas, which involves
             * four full-size image blits.  An optimization would be to track the
             * dirty rectangle in scratchLine(), and only redraw that portion (i.e.
             * in each drawImage() call, pass the dirty rectangle as well--check out
             * the drawImage() documentation for details.)  This would scale to
             * arbitrary-sized images, whereas in its current form, it will dog out
             * if the images are large.
             */
            function recompositeCanvases() {
                var main = $('#maincanvas').get(0);
                var tempctx = canvas.temp.getContext('2d');
                var mainctx = main.getContext('2d');

                // Step 1: clear the temp
                canvas.temp.width = canvas.temp.width; // resizing clears

                // Step 2: stamp the draw on the temp (source-over)
                tempctx.drawImage(canvas.draw, 0, 0);

                // Step 3: stamp the background on the temp (!! source-atop mode !!)
                tempctx.globalCompositeOperation = 'source-atop';
                tempctx.drawImage(image.back.img, 10, 10);
                tempctx.font = "40px Arial";
                tempctx.fillStyle = "black";
                //tempctx.fillText("一等奖", 40, 250);
                <?php
                $prize_text="";
                if ($_SESSION['prize']==1) {
                    $prize_text = "一等奖";
                }else if ($_SESSION['prize']==2) {
                    $prize_text = '二等奖';
                }else {
                    $prize_text = '三等奖';
                }
                ?>
                tempctx.fillText("<?php echo $prize_text;?>", 40, 250);


                // Step 4: stamp the foreground on the display canvas (source-over)
                mainctx.drawImage(image.front.img, 0, 0);

                // Step 5: stamp the temp on the display canvas (source-over)
                mainctx.drawImage(canvas.temp, 0, 0);

            }

            /**
             * Draw a scratch line
             *
             * @param can the canvas
             * @param x,y the coordinates
             * @param fresh start a new line if true
             */
            function scratchLine(can, x, y, fresh) {
                var ctx = can.getContext('2d');
                ctx.lineWidth = 45;
                ctx.lineCap = ctx.lineJoin = 'round';
                ctx.strokeStyle = "white"; // can be any opaque color
                if (fresh) {
                    ctx.beginPath();
                    // this +0.01 hackishly causes Linux Chrome to draw a
                    // "zero"-length line (a single point), otherwise it doesn't
                    // draw when the mouse is clicked but not moved:
                    ctx.moveTo(x+0.01, y);
                }
                ctx.lineTo(x, y);
                ctx.stroke();
            }

            /**
             * Set up the main canvas and listeners
             */
            function setupCanvases() {
                var c = $('#maincanvas').get(0);

                // set the width and height of the main canvas from the first image
                // (assuming both images are the same dimensions)
                c.width = image.front.img.width;
                c.height = image.front.img.height;

                // create the temp and draw canvases, and set their dimensions
                // to the same as the main canvas:
                canvas.temp = document.createElement('canvas');
                canvas.draw = document.createElement('canvas');
                canvas.temp.width = canvas.draw.width = c.width;
                canvas.temp.height = canvas.draw.height = c.height;

                // draw the stuff to start
                recompositeCanvases();

                /**
                 * On mouse down, draw a line starting fresh
                 */
                function mousedown_handler(e) {
                    var local = getLocalCoords(c, getEventCoords(e));
                    mouseDown = true;

                    scratchLine(canvas.draw, local.x, local.y, true);
                    recompositeCanvases();

                    return false;
                };

                /**
                 * On mouse move, if mouse down, draw a line
                 *
                 * We do this on the window to smoothly handle mousing outside
                 * the canvas
                 */
                function mousemove_handler(e) {
                    if (!mouseDown) { return true; }

                    var local = getLocalCoords(c, getEventCoords(e));

                    scratchLine(canvas.draw, local.x, local.y, false);
                    recompositeCanvases();

                    return false;
                };

                /**
                 * On mouseup.  (Listens on window to catch out-of-canvas events.)
                 */
                function mouseup_handler(e) {
                    if (mouseDown) {
                        mouseDown = false;
                        return false;
                    }

                    return true;
                };

                $('#maincanvas').on('mousedown', mousedown_handler)
                    .on('touchstart', mousedown_handler);

                $(document).on('mousemove', mousemove_handler);
                $(document).on('touchmove', mousemove_handler);

                $(document).on('mouseup', mouseup_handler);
                $(document).on('touchend', mouseup_handler);
            }

            /**
             * Set up the DOM when loading is complete
             */
            function loadingComplete() {
                $('#loading').hide();
                $('#main').show();
            }

            /**
             * Handle loading of needed image resources
             */
            function loadImages() {
                var loadCount = 0;
                var loadTotal = 0;
                var loadingIndicator;

                function imageLoaded(e) {
                    loadCount++;

                    if (loadCount >= loadTotal) {
                        setupCanvases();
                        loadingComplete();
                    }
                }

                for (k in image) if (image.hasOwnProperty(k))
                    loadTotal++;

                for (k in image) if (image.hasOwnProperty(k)) {
                    image[k].img = document.createElement('img'); // image is global
                    $(image[k].img).on('load', imageLoaded);
                    image[k].img.src = image[k].url;
                }
            }

            /**
             * Handle page load
             */
            $(function() {
                if (supportsCanvas()) {
                    loadImages();

                    $('#resetbutton').on('click', function() {
                        // clear the draw canvas
                        canvas.draw.width = canvas.draw.width;
                        recompositeCanvases()

                        return false;
                    });
                } else {
                    $('#loading').hide();
                    $('#lamebrowser').show();
                }
            });

        })();

    </script>
</head>
<!-- <body background="scratcher_images/black1.jpg"> -->
<body background="scratcher_images/blue.jpg">
<form action="f.php" method="post">
    <header>
        <div>
            <button type='button' class="btn" onClick="location.href='logout.php'" style="float:right; font-size:11px; padding: 3px 5px 3px 5px;">登出</button>
            <span style="font-size:14px;">欢迎， <?php echo $_SESSION['name'];?> </span>
        </div>
        <br>
        <div class="logo">
            <h1>1661HK.com</h1>
            <hr noshade size=2 width="80%">
            <h3>Sports Fitness Lifestyle</h3>
        </div>
        <br>
        <div style="text-align:center;">如果您刮到奖品，请把二维码拿给工作人员扫描，兑换奖品。</div>
    </header>

    <?php
//        //if there is error in $_SESSION, then show it:
//        if (isset($_SESSION['error'])){
//            echo '<div class="error_msg">';
//            echo $_SESSION['error'];
//            echo '</div>';
//        }
    ?>

<!--    <div>-->
<!--        <img id="fullResImage" src="http://chart.apis.google.com/chart?chs=250x250&amp;cht=qr&amp;chld=L|4&amp;choe=UTF-8&amp;chl=http%3A%2F%2Flocalhost%3A8080%2Ff%2Fredeem_souvenir.php?id=--><?php //echo $_SESSION['id']?><!--" style="height: 250px; width: 250px;">-->
<!--    </div>-->

    <div>
        <canvas id="maincanvas" width="200" height="300" style="padding:0; margin:auto;display:block;"></canvas>
    </div>
    <div style="text-align: center; font-size:12px;">
        非触屏手机？点<button type="button" class="btn" style="font-size:12px; padding: 3px 5px 3px 5px;" onClick="showScratchResult();">这里</button>看你的刮刮乐奖品。
    </div>

    <div id="scratch_result" style="display:none;color:green">
        您刮开了刮刮乐，看到了如下字样： <?php echo $_SESSION['prize'];?>等奖。
    </div>
    <hr noshade size=2 width="80%">
    <header>
        <h3 style="text-align:center;">免费抽大奖</h3>
        <!--
        <div style="font-size:85%;">我们10.28-11.1号活动期间  每晚8点 在 1661HK摊位 举行现场抽奖。被抽中的顾客将会收到短信通知。如果10分钟内该客户没有来领奖，就视为自动放弃领奖资格。</div>
        -->
    </header>

    <div id="raffle_code" style="text-align:center;">
        ID: <p></p><span style='color:#6096b2; font-size:40px;font-family: 'Bodoni MT';'><?php echo $_SESSION['raffle_code'];?></span><p></p> <!--请妥善保管。-->
    </div>
    <div style="text-align:center; font-size:12px;">1661HK.com感谢您的参与，祝您好运！</div>
</form>

<script>
    function showScratchResult(){
        var result_div=document.getElementById('scratch_result');
        result_div.style.display='block';
    }
</script>




</body>
</html>