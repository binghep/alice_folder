<?php
session_start();
if (isset($_SESSION['id'])){//if exists, then the user is logged in, redirect to my_prize.php
    unset($_SESSION['id']);
    unset($_SESSION['name']);
    unset($_SESSION['my_referral_code']);
    header('Location: f.php');
}else{
    header('Location: f.php');
}