CREATE TABLE alice_user (
  id integer PRIMARY KEY NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL,
  email varchar(50) NOT NULL,
  mobile varchar(20) NOT NULL,
  s tinyint unsigned NOT NULL, -- represents type of souvenir: 1: first prize  2: second prize 3: third prize
  raffle_code varchar(20) NOT NULL, -- used in the raffle
  valid BOOLEAN NOT NULL,  -- represents whether the user has registered and has their QR code scanned by us.
	register_time datetime,
 	redeem_time datetime
) ;

-- CREATE TABLE alice_user (
--   id integer PRIMARY KEY NOT NULL AUTO_INCREMENT,
--   name varchar(255) NOT NULL,
--
--   email varchar(50) NOT NULL,
--   mobile varchar(20) NOT NULL,
--   s tinyint unsigned NOT NULL, -- represents type of souvenir: 1: first prize  2: second prize 3: third prize
--   raffle_code varchar(20) NOT NULL, -- used in the raffle
--   valid BOOLEAN NOT NULL  -- represents whether the user has registered and has their QR code scanned by us.
--   register_time timestamp TIMESTAMP NOT NULL,
--   redeem_time timestamp TIMESTAMP
-- ) ;




-- BOOL and BOOLEAN are synonyms of TINYINT(1). Zero is false, anything else is true. More information here.
INSERT INTO alice_user (`id`, `name`, `email`, `mobile`, `s`, `raffle_code`, `valid`, `register_time`) VALUES
(9, 'john doe', 'john@gmail.com', '13853388888', 1, '98248',1, NOW()),
(10, 'Bill Gates', 'bill@gmail.com', '13658656666', 2, '58872',1, NOW()),
(11, 'Emily Yu', 'emily@gmail.com', '13966688888', 3, '54422',1, NOW());


-- prize table
create table alice_prize (
  id integer PRIMARY KEY NOT NULL,
  name varchar(50) NOT NULL,
  stock integer NOT NULL
)
INSERT INTO `magento_1661`.`alice_prize` (`id`, `name`, `stock`) VALUES (1, 'first prize', 100);
INSERT INTO `magento_1661`.`alice_prize` (`id`, `name`, `stock`) VALUES (2, 'second prize', 100);
INSERT INTO `magento_1661`.`alice_prize` (`id`, `name`, `stock`) VALUES (3, 'third prize', 4000);
--