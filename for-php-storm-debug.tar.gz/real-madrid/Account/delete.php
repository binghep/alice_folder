<?php
require_once("../database/dbcontroller.php");
$db_handle = new DBController();
if(!empty($_GET["id"])) {
	$result = $db_handle->runQuery("DELETE FROM alice_survey WHERE id=".$_GET["id"]);
	if($result===true){
		header("Location:index.php");
	}
}
?>