<?php
require_once("../database/dbcontroller.php");
$db_handle = new DBController();
if(!empty($_POST["submit"])) {
	$result = mysql_query("INSERT INTO alice_user(name, email, mobile, s) VALUES('".$_POST["name"]."','".$_POST["email"]."','".$_POST["mobile"]."','".$_POST["s"]."','".$_POST["r"]."')");
	if(!$result){
			$message="Problem in Adding to database. Please Retry.";
	} else {
		header("Location:index.php");
	}
}
?>
<html>
	<head>
	<link href="style.css" type="text/css" rel="stylesheet" />
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	</head>

	<body>
	<form name="frmToy" method="post" action="" id="frmToy" onClick="return validate();">
		<div id="mail-status"></div>
		<div>
			<label>Name</label>
			<span id="name-info" class="info"></span><br/>
			<input type="text" name="name" id="name" class="demoInputBox">
		</div>

		<div>
			<label>Email</label>
			<span id="email-info" class="info"></span><br/>
			<input type="text" name="email" id="email" class="demoInputBox">
		</div>

		<div>
			<label>Mobile</label>
			<span id="mobile-info" class="info"></span><br/>
			<input type="text" name="mobile" id="mobile" class="demoInputBox">
		</div>

		<div>
			<label>Prize</label>
			<span id="s-info" class="info"></span><br/>
			<input type="text" name="s" id="s" class="demoInputBox">
		</div>
        
        <div>
			<label>Raffle Code</label>
			<span id="r-info" class="info"></span><br/>
			<input type="text" name="r" id="r" class="demoInputBox">
		</div>

		<div>
			<input type="submit" name="submit" id="btnAddAction" value="Add" />
		</div>
		</div>
	</form>
	<script>
		function validate() {
			var valid = true;
			$(".demoInputBox").css('background-color','');
			$(".info").html('');

			if(!$("#name").val()) {
				$("#name-info").html("(required)");
				$("#name").css('background-color','#FFFFDF');
				valid = false;
			}
			if(!$("#email").val()) {
				$("#email-info").html("(required)");
				$("#email").css('background-color','#FFFFDF');
				valid = false;
			}
			if(!$("#mobile").val()) {
				$("#mobile-info").html("(required)");
				$("#mobile").css('background-color','#FFFFDF');
				valid = false;
			}
			if(!$("#s").val()) {
				$("#s-info").html("(required)");
				$("#s").css('background-color','#FFFFDF');
				valid = false;
			}
			if(!$("#r").val()) {
				$("#r-info").html("(required)");
				$("#r").css('background-color','#FFFFDF');
				valid = false;
			}
			return valid;
		}
	</script>
	</body>
</html>