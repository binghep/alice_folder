<?php
// function getPrizeName($prize_id){
//  $prize_text="";
//     switch ((int)$prize_id){
//         case 1:
//             $prize_text = '1';
//             break;
//         case 2:
//             $prize_text = '2';
//             break;
//         case 3:
//             $prize_text = '3';
//             break;
//         case 4:
//             $prize_text = '4';
//             break;
//         case 5:
//             $prize_text = '(5)选手1';
//             break;
//         case 6:
//             $prize_text = '(6)选手2';
//             break;
//         case 7:
//             $prize_text = '(7)选手3';
//             break;
//         case 8:
//             $prize_text = '(8)选手out of prize';//'we have run out of prize for runners.'
//             break;
//         case defaut:
//             $prize_text = 'error';
//             break;
//     }
//     return $prize_text;
// }

require_once("perpage.php");
require_once("../database/dbcontroller.php");
$db_handle = new DBController();

function getName($region_id,$db_handle){
    $sql="select * from global_region where region_id=".$region_id;
    $result = $db_handle->runQuery($sql);
    if (!empty($result)){
        return $result[0]['region_name'];
    }else{
        return 'not valid';
    }
}

$id = "";
$name = "";
$referrer="";

$queryCondition = "";
if (!empty($_POST["search"])) {
    foreach ($_POST["search"] as $k => $v) {
        if (!empty($v)) {

            $queryCases = array("id", "name","referrer");
            if (in_array($k, $queryCases)) {
                if (!empty($queryCondition)) {
                    $queryCondition .= " AND ";
                } else {
                    $queryCondition .= " WHERE ";
                }
            }
            switch ($k) {
                case "id":
                    $id = $v;
                    $queryCondition .= "id LIKE '" . $v . "%'";
                    break;
                case "name":
                    $code = $v;
                    $queryCondition .= "name LIKE '" . $v . "%'";
                    break;
                case "referrer":
                    $referrer=$v;
                    $queryCondition .= "referrer = '" . $v . "'";
                    break;
            }
        }
    }
}
$orderby = " ORDER BY id desc";
$sql = "SELECT * FROM alice_survey " . $queryCondition;
$href = 'index.php';

$perPage = 40;//20
$page = 1;
if (isset($_POST['page'])) {
    $page = $_POST['page'];
}
$start = ($page - 1) * $perPage;
if ($start < 0) $start = 0;

$query = $sql . $orderby . " limit " . $start . "," . $perPage;
//echo $query;
$result = $db_handle->runQuery($query);
// perpage is the last row in $result:
if (!empty($result)) {//if is not null, prepare the rows to display
    $result["perpage"] = showperpage($sql, $perPage, $href);
}else{
    echo 'alice_user table doesnt exit, or there are no users in this table';
}
?>
<html>
<head>
    <title>Manage User</title>
    <link href="style.css" type="text/css" rel="stylesheet"/>
    <meta charset="UTF-8">
</head>
<body>
<h2>Manage User</h2>
<!--
<div style="text-align:right;margin:20px 0px 10px;">
    <a id="btnAddAction" href="add.php">Add New</a>
</div>
-->
<div id="toys-grid">
    <form name="frmSearch" method="post" action="index.php" style="width:200%;">
        <div class="search-box">
            <p>
                <input type="text" placeholder="Id" name="search[id]" class="demoInputBox" value="<?php echo $id; ?>"/>
                <input type="text" placeholder="Name" name="search[name]" class="demoInputBox"
                       value="<?php echo $name; ?>"/>
                <input type="text" placeholder="Referrer" name="search[referrer]" class="demoInputBox" value="<?php echo $referrer; ?>"/>
                <input type="submit" name="go" class="btnSearch" value="Search">
                <input type="reset" class="btnSearch" value="Reset" onClick="window.location='index.php'">
            </p>
        </div>

        <table cellpadding="10" cellspacing="1">
            <thead>
            <tr>
                <th><strong>Id</strong></th>
                <th><strong>Name</strong></th>
                <th><strong>Email</strong></th>
                <th><strong>Mobile</strong></th>
                <th><strong>Education</strong></th>
                <th><strong>My Referral Code</strong></th>
                <th><strong>Gender</strong></th>
                <th><strong>Age</strong></th>
                <th><strong>Occupation</strong></th>
                <th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Register Time&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong></th>
                <th><strong>Province</strong></th>
                <th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;City</strong></th>
                <th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;District</strong></th>
                <th><strong>Referrer</strong></th>
                <th><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</strong></th>
            </tr>
            </thead>
            <tbody>
            <?php
            //var_dump($result);
            if (is_null($result)) {echo 'no record found.'; exit;}
            foreach ($result as $k => $v) {
                if (is_numeric($k)) {
                    ?>
                    <tr>
                        <td><?php echo $result[$k]["id"]; ?></td>
                        <td><?php echo htmlspecialchars($result[$k]["name"],ENT_QUOTES); ?></td>
                        <td><?php echo htmlspecialchars($result[$k]["email"]); ?></td>
                        <td><?php echo $result[$k]["mobile"]; ?></td>
                        <td><?php echo $result[$k]["education"]; ?></td>
                        <td><?php echo $result[$k]["my_referral_code"]; ?></td>
                        <td><?php echo $result[$k]["gender"]; ?></td>
                        <td><?php echo $result[$k]["age"]; ?></td>
                        <td><?php echo $result[$k]["occupation"]; ?></td>
                        <td><?php echo $result[$k]["register_time"]; ?></td>
                        <td><?php echo getName($result[$k]["region_province"],$db_handle); ?></td>
                        <td><?php echo getName($result[$k]["region_city"],$db_handle); ?></td>
                        <td><?php echo getName($result[$k]["region_district"],$db_handle); ?></td>
                        <td><?php echo $result[$k]["referrer"]; ?></td>
                        <td>
                            <!--<a class="btnEditAction" href="edit.php?id=<?php echo $result[$k]["id"]; ?>">Edit</a>--> <a
                                class="btnDeleteAction"
                                href="delete.php?action=delete&id=<?php echo $result[$k]["id"]; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
            }
            if (isset($result["perpage"])) {
                ?>
                <tr>
                    <td colspan="15" align=right> <?php echo $result["perpage"]; ?></td>
                </tr>
                <?php
            }
            ?>
            <tbody>
        </table>
    </form>
</div>
</body>
</html>