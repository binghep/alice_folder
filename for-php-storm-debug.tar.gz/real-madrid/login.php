<?php
session_start();

if ($_SESSION['event']!='real-madrid'){
    $_SESSION['event']='real-madrid';
    header('Location: logout.php');
}

if (isset($_SESSION['id'])){//if exists, then the user is logged in, redirect to my_prize.php
    header('Location: my_home.php');
}

$_SESSION['error']='';

if (isset($_POST['submit'])) {
    //if mobile is empty:
    if (empty($_POST['mobile'])){
        $_SESSION['error'] = '请输入手机号<br>';
    }
    //validate mobile based on its own rule:
    else if (!is_numeric($_POST['mobile'])){
        $_SESSION['error'] ='手机号只能包含数字<br>';
    } else {
        //passed validation:
        require("database/dbcontroller.php");
        $db_handle = new DBController();
        require("config.php");
        $sql = "SELECT * FROM alice_promotions WHERE promotion_event_id=".$event_id." and mobile='" . $_POST['mobile'] . "'";
        $result = $db_handle->runQuery($sql);

        if (!is_null($result) && $result) {//is not null and not false. returns null if 没有被注册过
            //found the user record:
            //xdebug_var_dump($result);
            $id = $result[0]['id'];
            $name=$result[0]['name'];
            $my_referral_code=$result[0]['my_referral_code'];

            //echo $id;
            $_SESSION['id']=$id;//log him in.
            $_SESSION['name']=$name;//these two must be together.
            $_SESSION['my_referral_code']=$my_referral_code;
           
            //invalidate the mobile code:
            unset($_SESSION['mobile']);
            unset($_SESSION['sms_code']);
            //exit;
            header('Location: my_home.php');
        }else{
            //no such record:
            $_SESSION['error']='此手机号没有被注册过';
        }
    }
}
?>

<html>
<head>
<!--    <meta charset="UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>查询</title>
    <link href="css/form5.css" type="text/css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<!-- <body background="scratcher_images/black1.jpg"> -->
<!-- <body background="scratcher_images/blue.jpg"> -->
<body>
<form action="login.php" method="post">
    <image style='display: block;margin: 0 auto;float: left;
width: 100px;' src='scratcher_images/1661HK_Logo_05152015__1.png'>
    </image>
    <br>
    
    <header>
        <h2>查询您的介绍人代码</h2>
        <div>(1) 请输入您登记时用的手机号.</div>
        <div>(2) 注:如果您没有登记过,请点击 <button type='button' class='btn' onClick="location.href='f.php'">这里</button>填表并验证手机号.</div>
    </header>

    <?php
        //if there is error in $_SESSION, then show it:
        if (isset($_SESSION['error'])){
            echo '<div class="error_msg">';
            echo $_SESSION['error'];
            echo '</div>';
        }
    ?>

    <div>
        <div>
            <input id="mobile" name="mobile" type="number" placeholder="手机号" value="<?php if (isset($_POST['mobile'])) echo $_POST['mobile'];?>" maxlength="15" tabindex="3">
        </div>
    </div>

    <div>
        <div>
            <input id="saveForm" name="submit" type="submit" class='submit' value="查询">
        </div>
    </div>
</form>
</body>
</html>