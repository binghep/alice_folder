<?php

session_start();
//captcha is not expired, meaning the session variable is not changed.
if (isset($_GET['user_input'])){
    if (!isset($_SESSION['captcha'])) {
       // $result = array('status' => false,
        //    'msg' => 'please refresh the page. 验证码过期，请刷新页面。'
        //);
        echo 'fail. please refresh the page. 验证码过期，请刷新页面。';
    }
    //if user enters the wrong captcha:
    if (strtolower($_SESSION['captcha']['code'])!==strtolower($_GET['user_input'])){
       // $result=array('status' => false,
       //     'msg'=>'wrong captcha code. 验证码不正确。');
        echo 'fail. wrong captcha code. 验证码不正确。';
    }else {
        //$result=array('status' => true,
        //    );
        echo 'pass';
    }
}else{
    //echo array('status' => false,
    //    'msg'=>'session variable not here');
    echo 'fail. session variable not here';
}