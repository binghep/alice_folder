<?php
session_start();
if (isset($_SESSION['id'])){//if exists, then the user is logged in, redirect to my_prize.php
    unset($_SESSION['id']);
    unset($_SESSION['name']);
    unset($_SESSION['my_referral_code']);
    echo 'successfully unset...going back to f.php';
    exit;
    header('Location: f.php');
}else{
	echo 'session id is not set...going back to f.php';
    exit;
    header('Location: f.php');
}