<?php
	/*
	========estimate (7 days)========= 
	1k--first prize,
	1k--second prize,
	6k--third prize,
	40k--paticipants of the events. 
	========estimate (per day)=========
	143--first prize,
	143--second prize,
	857--third prize,
	5714--average number of new user showing up there per day. --> pls change this on the fly. I will estimate 30K-40K on one of those days, because during 7 days, only 1 day is marathon. the others are canivals.   	
	*/
    
    //the following 3 lines are on a daily basis, they are used to simulate prize drawing process:
   
    $num_users_per_day=2000;//3333 people register per day.
    $num_first_prize=30;//must not be 0
    $num_second_prize=30;//must not be 0
    $ratio_first=$num_first_prize/(float)$num_users_per_day; //if user's random number between 0 and 1 is < $ratio_first, then he gets the first prize (also, when stock is available).
    //echo $ratio_first;
    $ratio_second=($num_second_prize+$num_first_prize)/(float)$num_users_per_day;//if the user's random number is between $ratio_first and $ratio_second, then he gets the 2nd prize. else. he gets the 3rd prize.
	//$a=31;
	//$b=32;
	//$p1= $u/$a;
	//$p2= $u/$b;





    //---------------------------------------------------------------------
    //whether the application is to be run on localhost or hk.1661hk.com
    //$base_url="192.168.0.169";
  	// $base_url="hk.1661hk.com"; 
  	$base_url="www.1661hk.com"; 


    //---------------------------------------------------------------------
    $texting_interval=60;//seconds
    $texting_quota=100; //used in line 22 in SMS/SMS.php and SMS_US.php. When we are testing, if you can't register, which means you run out of texting quota, just go to http://localhost/f/refresh_text_quota.php, and session['texting_quota'] is unset automatically.
    $allow_us_mobile=true; //whether you allow U.S. number
	//---------------------------------------------------------------------
	$debug=true;//if debug is true, no need to enter 短信验证码/SMS Verification Code/last entry in f.php 
	//---------------------------------------------------------------------
	$event_name='kobe-bryant';
	$event_id=2;