<?php
session_start();

if ($_SESSION['event']!='kobe-bryant'){
    $_SESSION['event']='kobe-bryant';
    header('Location: logout.php');
}

if (!isset($_SESSION['id'])){//if exists, then the user is logged in. otherwise redirect to enter mobile page
    header('Location: login.php');
}
require "config.php";
require("database/dbcontroller.php");
$db_handle = new DBController();
$result=$db_handle->runQuery('select * from alice_promotion_kobe_bryant where referrer="'.$_SESSION['my_referral_code'].'" order by id DESC');//returns null if empty resultset
//var_dump($result);
$num=0;
if (!is_null($result)){
    foreach ($result as $k => $v) {
        //$result[$k]
       // echo $result[$k]['name']. ' '.$result[$k]['register_time'];
        $num++;
    }
}

?>
<html>
<head>
<!--    <meta charset="UTF-8">-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>我的主页</title>
    <link href="css/form5.css" type="text/css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jquery, CSS, and scripts for scratcher -->
    <script src="js/jquery.min.js"></script>
    <link href="css/scratcher.css" rel="stylesheet" type="text/css"/>
</head>
<!-- <body background="scratcher_images/black1.jpg"> -->
<!-- <body background="scratcher_images/blue.jpg"> -->
<body>
<form action="f.php" method="post">
    <image style='display: block;margin: 0 auto;float: left;
width: 100px;' src='scratcher_images/1661HK_Logo_05152015__1.png'>
    </image>
    <button type='button' class="btn" onClick="location.href='logout.php'" style="float:right; font-size:12px; padding: 4px 8px 4px 8px;">登出</button>
    	<div style="padding: 0;margin: 0 auto;text-align: left;display: block;">
	    	<h3 style="float: left;text-align: left; position: relative; width: 100%;margin: 10px 0;"> 科比系列 篮球球衣 抽奖活动</h3>
    	</div>

    <br>
    <!-- <header> -->
        <div>
            <span style="font-size:17px;">欢迎， <?php echo $_SESSION['name'];?> </span>
        </div>
    <!-- </header> -->

    <hr noshade size=2 width="100%">        
    <div>
    	您的介绍人号码是：
    	<span style='color:#006AA0; font-size:20px;font-family: 'Bodoni MT';'>
    		<?php echo $_SESSION['my_referral_code'];?>
    	</span>
		<br>
		<br>
		<span style='font-size:15px;color:#00940D;'>注：如果您介绍其他用户注册（用户注册时填入您的介绍人号码），您被抽中的几率会更大哦。</span>
    </div>

    <div>
	    <h4>
	    	您总共介绍了<?php echo $num;?>个用户注册。
	    	<?php
			if (!is_null($result)){
	    		echo "以下为经您介绍注册的用户：";
	    	}
	    	?>
	    </h4>
    </div>
    <?php
    if (!is_null($result)){
    	//echo "<h3 style='text-align:center;'>以下为经您推荐注册的用户：</h3>";
    	echo "<div style='text-align:center;'>";
        foreach ($result as $k => $v) {
           echo "<div style='width:100%;float:none;'>".$result[$k]['name']. '   '.$result[$k]['register_time']."</div>";
        }
        echo "</div>";
    }
    ?>

    <hr noshade size=2 width="100%">

    <!-- 
    <div id="raffle_code" style="text-align:center;display:none;">
        ID: <p></p><span style='color:#6096b2; font-size:40px;font-family: 'Bodoni MT';'><?php echo $_SESSION['raffle_code'];?></span><p></p> 
    </div>
    <div style="text-align:center; font-size:12px;">想要最新的科技运动装备吗?点<a href='http://www.1661hk.com/innovation'>这里</a>。<br>1661HK.com感谢您的参与，祝您好运！</div>
 	-->
 </form>

</body>
</html>